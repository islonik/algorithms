import java.util.*;

/**
 * @author Lipatov Nikita
 */
public class KdTree {
    private static final boolean IS_VERTICAL = true;
    private static final double DEGREE = 2.0;
    private static final int IS_RIGHT =  1;
    private static final int IS_LEFT  = -1;
    private static final int IS_ZERO  =  0;

    private Node root;
    private Node nearest;
    private int size = 0;

    public KdTree() {
    }

    public boolean isEmpty() {
        if (root == null) {
            return true;
        }
        return false;
    }

    public int size() {
        return size;
    }

    public void insert(Point2D p) {
        if (isEmpty()) {
            root = new Node(p, new RectHV(0, 0, 1, 1));
            size++;
        } else if(!contains(p)) {
            insertTree(root, root, p, IS_VERTICAL, IS_ZERO);
            size++;
        }
    }

    private Node insertTree(Node root, Node parent, Point2D point, boolean isVertical, int order) {
        if (parent == null) {
            RectHV rect = createRectHV(root, isVertical, order);
            return new Node(point, rect);
        }

        int cmp = compare(isVertical, parent.p, point);
        if (cmp < 0) {
            parent.left  = insertTree(parent, parent.left,  point, !isVertical, IS_LEFT);
        } else if (cmp > 0) {
            parent.right = insertTree(parent, parent.right, point, !isVertical, IS_RIGHT);
        }
        return parent;
    }

    private RectHV createRectHV(Node root, boolean isVertical, int order) {
        RectHV rect = null;
        isVertical = !isVertical; // restore position
        if (isVertical) {
            if (IS_LEFT == order) {
                rect = new RectHV(root.rect.xmin(), root.rect.ymin(), root.p.x(), root.rect.ymax());
            } else {
                rect = new RectHV(root.p.x(), root.rect.ymin(), root.rect.xmax(), root.rect.ymax());
            }
        } else { // isHorizontal
            if (IS_LEFT == order) {
                rect = new RectHV(root.rect.xmin(), root.rect.ymin(), root.rect.xmax(), root.p.y());
            } else {
                rect = new RectHV(root.rect.xmin(), root.p.y(), root.rect.xmax(), root.rect.ymax());
            }
        }
        return rect;
    }

    private int compare(boolean isVertical, Point2D p1, Point2D p2) {
        if (isVertical) {
            double xdif = p2.x() - p1.x();
            if (xdif < 0) {
                return -1;
            } else if (xdif > 0) {
                return  1;
            } else {
                double ydif = p2.y() - p1.y();
                if (ydif < 0) {
                    return -1;
                } else if (ydif > 0) {
                    return  1;
                } else {
                    return  0;
                }
            }
        } else {
            double ydif = p2.y() - p1.y();
            if (ydif < 0) {
                return -1;
            } else if (ydif > 0) {
                return  1;
            } else {
                double xdif = p2.x() - p1.x();
                if (xdif < 0) {
                    return -1;
                } else if (xdif > 0) {
                    return  1;
                } else {
                    return  0;
                }
            }
        }
    }

    public boolean contains(Point2D p) {
        return contains(root, p, IS_VERTICAL);
    }

    private boolean contains(Node parent, Point2D point, boolean isVertical) {
        if (parent == null) {
            return false;
        } else if (parent.p.equals(point)) {
            return true;
        }
        int cmp = compare(isVertical, parent.p, point);
        if (cmp < 0) {
            return contains(parent.left,  point, !isVertical);
        } else if (cmp > 0) {
            return contains(parent.right, point, !isVertical);
        }
        return false;
    }

    public void draw() {
        draw(root, IS_VERTICAL);
    }

    private void draw(Node parent, boolean isVertical) {
        StdDraw.setPenRadius(0.005);
        StdDraw.setPenColor(StdDraw.BLACK);  // point
        parent.p.draw();
        if (isVertical) {
            StdDraw.setPenRadius(0.001);
            StdDraw.setPenColor(StdDraw.RED);  // vertical
            StdDraw.line(parent.p.x(), parent.rect.ymin(), parent.p.x(), parent.rect.ymax());
        } else {
            StdDraw.setPenRadius(0.001);
            StdDraw.setPenColor(StdDraw.BLUE); // horizontal
            StdDraw.line(parent.rect.xmin(), parent.p.y(), parent.rect.xmax(), parent.p.y());
        }

        if (parent.left != null) {
            draw(parent.left, !isVertical);
        }
        if (parent.right != null) {
            draw(parent.right, !isVertical);
        }
    }

    public Iterable<Point2D> range(RectHV rectHV) {
        final List<Point2D> rangePoints = new LinkedList<Point2D>();
        range(rangePoints, root, rectHV, IS_VERTICAL);
        return new Iterable<Point2D>() {
            public Iterator<Point2D> iterator() {
                return rangePoints.iterator();
            }
        };
    }

    private void range(List<Point2D> list, Node parent, RectHV rect, boolean isVertical) {
        if (parent.rect.intersects(rect)) {
            if (parent.p.x() <= rect.xmax() && parent.p.x() >= rect.xmin() && parent.p.y() <= rect.ymax() && parent.p.y() >= rect.ymin()) {
                list.add(parent.p);
            }
            if (parent.left != null) {
                range(list, parent.left,  rect, !isVertical);
            }
            if (parent.right != null) {
                range(list, parent.right, rect, !isVertical);
            }
        }
    }

    public Point2D nearest(Point2D p) {
        nearestPointThroughRects(root, p, IS_VERTICAL, DEGREE);
        return nearest.p;
    }

    private void nearestPointThroughRects(Node parent, Point2D point, boolean isVertical, double shortestWay) {
        if (parent == null) {
            return;
        }

        double currentDistance = calcDistance(point, parent.p);
        if (shortestWay > currentDistance) {
            nearest = parent;
            shortestWay = currentDistance;
        }
        int cmp = compare(isVertical, parent.p, point);
        if (cmp < 0 || calcDistance(parent.left,  point) < shortestWay) {
            nearestPointThroughRects(parent.left, point, !isVertical, shortestWay);
        }
        if (cmp > 0 || calcDistance(parent.right, point) < shortestWay) {
            nearestPointThroughRects(parent.right, point, !isVertical, shortestWay);
        }
    }

    private static double calcDistance(Node nthat, Point2D temp) {
        if (nthat == null) {
            return DEGREE;
        }
        Point2D that = nthat.p;
        return Math.sqrt(Math.pow(Math.abs(that.x() - temp.x()), DEGREE) + Math.pow(Math.abs(that.y() - temp.y()), DEGREE));
    }

    private static double calcDistance(Point2D that, Point2D temp) {
        return Math.sqrt(Math.pow(Math.abs(that.x() - temp.x()), DEGREE) + Math.pow(Math.abs(that.y() - temp.y()), DEGREE));
    }

    private static class Node {
        private Point2D p;      // the point
        private RectHV rect;    // the axis-aligned rectangle corresponding to this node
        private Node left;      // the left/bottom subtree
        private Node right;     // the right/top subtree

        public Node(Point2D p) {
            this.p = p;
        }

        public Node(Point2D p, RectHV rect) {
            this.p = p;
            this.rect = rect;
        }
    }

    // unit testing of the methods (optional)
    public static void main(String[] args) {

    }


}
